# import the necessary packages
from .resnet import ResNet