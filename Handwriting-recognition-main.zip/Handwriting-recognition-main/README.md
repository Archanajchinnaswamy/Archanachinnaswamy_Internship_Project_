# Handwriting-recognition
Handwriting Recognition( i,e Optical Character Recognition) with OpenCv, Keras and TensorFlow 2.0.0

